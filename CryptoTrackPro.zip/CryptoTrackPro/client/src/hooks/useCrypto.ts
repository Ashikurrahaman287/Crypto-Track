import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Cryptocurrency } from "@shared/schema";

interface PaginationData {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

interface CryptoResponse {
  data: Cryptocurrency[];
  pagination: PaginationData;
}

interface GlobalStats {
  totalCryptocurrencies: number;
  totalExchanges: number;
  totalMarketCap: number;
  totalVolume: number;
  marketCapPercentage: Record<string, number>;
  marketCapChangePercentage24h: number;
}

export function useCryptocurrencies(
  page = 1,
  limit = 100,
  currency = "usd",
  orderBy = "marketCapRank",
  order = "asc"
) {
  return useQuery<CryptoResponse, Error>({
    queryKey: [`/api/cryptocurrencies?page=${page}&limit=${limit}&currency=${currency}&orderBy=${orderBy}&order=${order}`],
    staleTime: 60 * 1000, // 1 minute
  });
}

export function useCryptocurrency(id: string | number) {
  return useQuery<Cryptocurrency, Error>({
    queryKey: [`/api/cryptocurrencies/${id}`],
    staleTime: 60 * 1000, // 1 minute
  });
}

export function useGlobalStats() {
  return useQuery<GlobalStats, Error>({
    queryKey: ['/api/stats/global'],
    staleTime: 60 * 1000, // 1 minute
  });
}

export function formatPrice(price: number | undefined, currency = 'USD'): string {
  if (price === undefined) return 'N/A';
  
  // Format based on price magnitude
  if (price < 0.000001) {
    return `$${price.toExponential(2)}`;
  } else if (price < 0.01) {
    return `$${price.toFixed(6)}`;
  } else if (price < 1) {
    return `$${price.toFixed(4)}`;
  } else if (price < 1000) {
    return `$${price.toFixed(2)}`;
  } else if (price < 1000000) {
    return `$${(price / 1000).toFixed(2)}K`;
  } else if (price < 1000000000) {
    return `$${(price / 1000000).toFixed(2)}M`;
  } else {
    return `$${(price / 1000000000).toFixed(2)}B`;
  }
}

export function formatPercent(percent: number | undefined): string {
  if (percent === undefined) return 'N/A';
  return `${percent > 0 ? '+' : ''}${percent.toFixed(2)}%`;
}

export function formatNumber(num: number | undefined): string {
  if (num === undefined) return 'N/A';
  
  if (num < 1000) {
    return num.toFixed(0);
  } else if (num < 1000000) {
    return `${(num / 1000).toFixed(1)}K`;
  } else if (num < 1000000000) {
    return `${(num / 1000000).toFixed(1)}M`;
  } else if (num < 1000000000000) {
    return `${(num / 1000000000).toFixed(1)}B`;
  } else {
    return `${(num / 1000000000000).toFixed(1)}T`;
  }
}
