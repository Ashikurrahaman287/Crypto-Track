import { useState } from 'react';
import { Link } from 'wouter';
import { useAuth } from '@/hooks/useAuth';
import { useTheme } from '@/hooks/useTheme';
import { Sun, Moon, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export default function Header() {
  const { user, logoutMutation } = useAuth();
  const { theme, setTheme, isDarkMode } = useTheme();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleTheme = () => {
    setTheme(isDarkMode ? 'light' : 'dark');
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <header className="sticky top-0 z-50 bg-white dark:bg-neutral-800 border-b border-neutral-200 dark:border-neutral-700">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link href="/" className="flex items-center space-x-2">
              <svg className="h-8 w-8 text-primary" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm-1-9.5v3a1 1 0 0 0 2 0v-3a2.5 2.5 0 1 0-2 0z"/>
              </svg>
              <span className="text-xl font-bold text-neutral-800 dark:text-white">CryptoTrack</span>
            </Link>
            <nav className="hidden md:flex ml-10 space-x-8">
              <Link href="/" className="text-neutral-500 dark:text-neutral-300 hover:text-primary dark:hover:text-primary font-medium">
                Cryptocurrencies
              </Link>
              <a href="#" className="text-neutral-500 dark:text-neutral-300 hover:text-primary dark:hover:text-primary font-medium">
                Exchanges
              </a>
              <a href="#" className="text-neutral-500 dark:text-neutral-300 hover:text-primary dark:hover:text-primary font-medium">
                NFTs
              </a>
              <a href="#" className="text-neutral-500 dark:text-neutral-300 hover:text-primary dark:hover:text-primary font-medium">
                Learn
              </a>
            </nav>
          </div>
          <div className="flex items-center space-x-4">
            <button 
              onClick={toggleTheme}
              className="p-2 rounded-full text-neutral-500 hover:bg-neutral-100 dark:hover:bg-neutral-700"
              aria-label="Toggle theme"
            >
              {isDarkMode ? (
                <Sun className="h-5 w-5" />
              ) : (
                <Moon className="h-5 w-5" />
              )}
            </button>
            <div className="relative">
              <Input
                type="text"
                placeholder="Search"
                className="pl-10 pr-4 py-2 w-40 md:w-64"
              />
              <div className="absolute left-3 top-2.5 text-neutral-400">
                <Search className="h-4 w-4" />
              </div>
            </div>
            {user ? (
              <div className="flex items-center space-x-2">
                <Link href="/admin">
                  <Button variant="outline" size="sm">Dashboard</Button>
                </Link>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={handleLogout}
                  disabled={logoutMutation.isPending}
                >
                  Logout
                </Button>
              </div>
            ) : (
              <Link href="/auth">
                <Button>Admin</Button>
              </Link>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
