import { Link } from 'wouter';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { FaTwitter, FaTelegramPlane, FaDiscord, FaGithub } from 'react-icons/fa';

export default function Footer() {
  return (
    <footer className="bg-white dark:bg-neutral-800 border-t border-neutral-200 dark:border-neutral-700 py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <svg className="h-8 w-8 text-primary" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm-1-9.5v3a1 1 0 0 0 2 0v-3a2.5 2.5 0 1 0-2 0z"/>
              </svg>
              <span className="text-xl font-bold text-neutral-800 dark:text-white">CryptoTrack</span>
            </div>
            <p className="text-sm text-neutral-600 dark:text-neutral-400">
              CryptoTrack provides cryptocurrency market data in real time. Our goal is to make crypto discovery and analysis accessible to all.
            </p>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-neutral-900 dark:text-white uppercase tracking-wider mb-4">Products</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-sm text-neutral-600 dark:text-neutral-400 hover:text-primary dark:hover:text-primary">Market Data</a></li>
              <li><a href="#" className="text-sm text-neutral-600 dark:text-neutral-400 hover:text-primary dark:hover:text-primary">Exchange Rankings</a></li>
              <li><a href="#" className="text-sm text-neutral-600 dark:text-neutral-400 hover:text-primary dark:hover:text-primary">API</a></li>
              <li><a href="#" className="text-sm text-neutral-600 dark:text-neutral-400 hover:text-primary dark:hover:text-primary">Widgets</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-neutral-900 dark:text-white uppercase tracking-wider mb-4">Company</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-sm text-neutral-600 dark:text-neutral-400 hover:text-primary dark:hover:text-primary">About</a></li>
              <li><a href="#" className="text-sm text-neutral-600 dark:text-neutral-400 hover:text-primary dark:hover:text-primary">Careers</a></li>
              <li><a href="#" className="text-sm text-neutral-600 dark:text-neutral-400 hover:text-primary dark:hover:text-primary">Press</a></li>
              <li><a href="#" className="text-sm text-neutral-600 dark:text-neutral-400 hover:text-primary dark:hover:text-primary">Contact</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-neutral-900 dark:text-white uppercase tracking-wider mb-4">Connect</h3>
            <div className="flex space-x-4">
              <a href="#" className="text-neutral-500 hover:text-primary">
                <FaTwitter className="text-lg" />
              </a>
              <a href="#" className="text-neutral-500 hover:text-primary">
                <FaTelegramPlane className="text-lg" />
              </a>
              <a href="#" className="text-neutral-500 hover:text-primary">
                <FaDiscord className="text-lg" />
              </a>
              <a href="#" className="text-neutral-500 hover:text-primary">
                <FaGithub className="text-lg" />
              </a>
            </div>
            <div className="mt-4">
              <form className="flex">
                <Input 
                  type="email" 
                  placeholder="Your email" 
                  className="rounded-r-none"
                />
                <Button className="rounded-l-none">Subscribe</Button>
              </form>
            </div>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-neutral-200 dark:border-neutral-700">
          <p className="text-center text-sm text-neutral-500 dark:text-neutral-400">
            &copy; {new Date().getFullYear()} CryptoTrack. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
