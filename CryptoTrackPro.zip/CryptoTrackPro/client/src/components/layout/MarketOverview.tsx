import { useGlobalStats, formatNumber, formatPrice, formatPercent } from '@/hooks/useCrypto';
import { Skeleton } from '@/components/ui/skeleton';

export default function MarketOverview() {
  const { data: stats, isLoading, error } = useGlobalStats();

  if (isLoading) {
    return (
      <section className="bg-white dark:bg-neutral-800 border-b border-neutral-200 dark:border-neutral-700 py-4">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[...Array(4)].map((_, index) => (
              <div key={index}>
                <Skeleton className="h-4 w-24 mb-2" />
                <Skeleton className="h-6 w-32" />
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section className="bg-white dark:bg-neutral-800 border-b border-neutral-200 dark:border-neutral-700 py-4">
        <div className="container mx-auto px-4">
          <div className="text-center text-red-500">
            Failed to load market overview data
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="bg-white dark:bg-neutral-800 border-b border-neutral-200 dark:border-neutral-700 py-4">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <p className="text-xs text-neutral-500 dark:text-neutral-400">Cryptocurrencies</p>
            <p className="font-medium">{formatNumber(stats?.totalCryptocurrencies)}</p>
          </div>
          <div>
            <p className="text-xs text-neutral-500 dark:text-neutral-400">Exchanges</p>
            <p className="font-medium">{formatNumber(stats?.totalExchanges)}</p>
          </div>
          <div>
            <p className="text-xs text-neutral-500 dark:text-neutral-400">Market Cap</p>
            <p className="font-medium">
              {formatPrice(stats?.totalMarketCap)} 
              <span className={`text-xs ml-1 ${stats?.marketCapChangePercentage24h && stats.marketCapChangePercentage24h >= 0 
                ? 'text-green-500' 
                : 'text-red-500'}`}>
                {formatPercent(stats?.marketCapChangePercentage24h)}
              </span>
            </p>
          </div>
          <div>
            <p className="text-xs text-neutral-500 dark:text-neutral-400">24h Vol</p>
            <p className="font-medium">{formatPrice(stats?.totalVolume)}</p>
          </div>
        </div>
      </div>
    </section>
  );
}
