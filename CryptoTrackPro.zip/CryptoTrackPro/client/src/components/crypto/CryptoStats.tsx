import { Cryptocurrency } from '@shared/schema';
import { formatPrice, formatPercent } from '@/hooks/useCrypto';
import { Skeleton } from '@/components/ui/skeleton';

interface CryptoStatsProps {
  crypto?: Cryptocurrency;
  isLoading: boolean;
}

export default function CryptoStats({ crypto, isLoading }: CryptoStatsProps) {
  return (
    <>
      <div className="bg-white dark:bg-neutral-800 rounded-lg shadow p-6 mb-6">
        <h2 className="text-lg font-bold mb-4">{crypto?.name || 'Cryptocurrency'} Price Statistics</h2>
        <div className="space-y-3">
          {isLoading ? (
            Array(7).fill(0).map((_, index) => (
              <div key={index} className="flex justify-between py-2 border-b border-neutral-100 dark:border-neutral-700">
                <Skeleton className="h-5 w-32" />
                <Skeleton className="h-5 w-24" />
              </div>
            ))
          ) : (
            <>
              <div className="flex justify-between py-2 border-b border-neutral-100 dark:border-neutral-700">
                <span className="text-sm text-neutral-500 dark:text-neutral-400">{crypto?.name} Price</span>
                <span className="text-sm font-medium">{formatPrice(crypto?.currentPrice)}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-neutral-100 dark:border-neutral-700">
                <span className="text-sm text-neutral-500 dark:text-neutral-400">24h Low / 24h High</span>
                <span className="text-sm font-medium">
                  {formatPrice(crypto?.low24h)} / {formatPrice(crypto?.high24h)}
                </span>
              </div>
              <div className="flex justify-between py-2 border-b border-neutral-100 dark:border-neutral-700">
                <span className="text-sm text-neutral-500 dark:text-neutral-400">Trading Volume</span>
                <span className="text-sm font-medium">{formatPrice(crypto?.totalVolume)}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-neutral-100 dark:border-neutral-700">
                <span className="text-sm text-neutral-500 dark:text-neutral-400">Market Cap Rank</span>
                <span className="text-sm font-medium">#{crypto?.marketCapRank || 'N/A'}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-neutral-100 dark:border-neutral-700">
                <span className="text-sm text-neutral-500 dark:text-neutral-400">All-Time High</span>
                <div className="text-right">
                  <div className="text-sm font-medium">{formatPrice(crypto?.ath)}</div>
                  <div className={`text-xs ${
                    crypto?.athChangePercentage && crypto.athChangePercentage >= 0 
                      ? 'text-green-500' 
                      : 'text-red-500'
                  }`}>
                    {formatPercent(crypto?.athChangePercentage)}
                  </div>
                  <div className="text-xs text-neutral-500 dark:text-neutral-400">
                    {crypto?.athDate 
                      ? formatDate(crypto.athDate)
                      : 'N/A'
                    }
                  </div>
                </div>
              </div>
              <div className="flex justify-between py-2">
                <span className="text-sm text-neutral-500 dark:text-neutral-400">All-Time Low</span>
                <div className="text-right">
                  <div className="text-sm font-medium">{formatPrice(crypto?.atl)}</div>
                  <div className={`text-xs ${
                    crypto?.atlChangePercentage && crypto.atlChangePercentage >= 0 
                      ? 'text-green-500' 
                      : 'text-red-500'
                  }`}>
                    {formatPercent(crypto?.atlChangePercentage)}
                  </div>
                  <div className="text-xs text-neutral-500 dark:text-neutral-400">
                    {crypto?.atlDate 
                      ? formatDate(crypto.atlDate)
                      : 'N/A'
                    }
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      <div className="bg-white dark:bg-neutral-800 rounded-lg shadow p-6">
        <h2 className="text-lg font-bold mb-4">{crypto?.name || 'Cryptocurrency'} Markets</h2>
        <div className="space-y-3">
          {isLoading ? (
            Array(4).fill(0).map((_, index) => (
              <div key={index} className="flex justify-between items-center p-3 bg-neutral-50 dark:bg-neutral-700 rounded-lg">
                <div className="flex items-center">
                  <Skeleton className="h-6 w-6 rounded-full" />
                  <Skeleton className="h-5 w-24 ml-2" />
                </div>
                <div className="text-right">
                  <Skeleton className="h-5 w-20" />
                  <Skeleton className="h-4 w-16 mt-1" />
                </div>
              </div>
            ))
          ) : (
            <>
              <div className="flex justify-between items-center p-3 bg-neutral-50 dark:bg-neutral-700 rounded-lg">
                <div className="flex items-center">
                  <img className="h-6 w-6 rounded-full" src="https://s2.coinmarketcap.com/static/img/exchanges/64x64/270.png" alt="Binance" />
                  <span className="ml-2 text-sm font-medium">Binance</span>
                </div>
                <div className="text-right">
                  <div className="text-sm font-medium">{formatPrice(crypto?.currentPrice)}</div>
                  <div className="text-xs text-neutral-500 dark:text-neutral-400">{crypto?.symbol}/USDT</div>
                </div>
              </div>
              <div className="flex justify-between items-center p-3 bg-neutral-50 dark:bg-neutral-700 rounded-lg">
                <div className="flex items-center">
                  <img className="h-6 w-6 rounded-full" src="https://s2.coinmarketcap.com/static/img/exchanges/64x64/89.png" alt="Coinbase" />
                  <span className="ml-2 text-sm font-medium">Coinbase</span>
                </div>
                <div className="text-right">
                  <div className="text-sm font-medium">{formatPrice(crypto?.currentPrice)}</div>
                  <div className="text-xs text-neutral-500 dark:text-neutral-400">{crypto?.symbol}/USD</div>
                </div>
              </div>
              <div className="flex justify-between items-center p-3 bg-neutral-50 dark:bg-neutral-700 rounded-lg">
                <div className="flex items-center">
                  <img className="h-6 w-6 rounded-full" src="https://s2.coinmarketcap.com/static/img/exchanges/64x64/24.png" alt="Kraken" />
                  <span className="ml-2 text-sm font-medium">Kraken</span>
                </div>
                <div className="text-right">
                  <div className="text-sm font-medium">{formatPrice(crypto?.currentPrice)}</div>
                  <div className="text-xs text-neutral-500 dark:text-neutral-400">{crypto?.symbol}/USD</div>
                </div>
              </div>
              <div className="flex justify-between items-center p-3 bg-neutral-50 dark:bg-neutral-700 rounded-lg">
                <div className="flex items-center">
                  <img className="h-6 w-6 rounded-full" src="https://s2.coinmarketcap.com/static/img/exchanges/64x64/294.png" alt="KuCoin" />
                  <span className="ml-2 text-sm font-medium">KuCoin</span>
                </div>
                <div className="text-right">
                  <div className="text-sm font-medium">{formatPrice(crypto?.currentPrice)}</div>
                  <div className="text-xs text-neutral-500 dark:text-neutral-400">{crypto?.symbol}/USDT</div>
                </div>
              </div>
            </>
          )}
          <button className="w-full mt-4 text-center text-primary text-sm font-medium">
            See All Markets
          </button>
        </div>
      </div>
    </>
  );
}

// Helper function to format dates
function formatDate(dateString: string): string {
  try {
    const date = new Date(dateString);
    const now = new Date();
    const diffInYears = now.getFullYear() - date.getFullYear();
    const diffInMonths = now.getMonth() - date.getMonth() + (diffInYears * 12);
    
    const formatter = new Intl.DateTimeFormat('en-US', { 
      month: 'short', 
      day: '2-digit', 
      year: 'numeric' 
    });
    const formattedDate = formatter.format(date);
    
    if (diffInYears > 1) {
      return `${formattedDate} (over ${diffInYears} years)`;
    } else if (diffInMonths > 1) {
      return `${formattedDate} (about ${diffInMonths} months)`;
    } else {
      return `${formattedDate} (recent)`;
    }
  } catch (error) {
    return 'Invalid date';
  }
}
