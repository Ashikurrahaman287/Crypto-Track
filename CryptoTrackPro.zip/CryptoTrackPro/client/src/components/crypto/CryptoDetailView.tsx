import { Link, useLocation } from 'wouter';
import { useCryptocurrency, formatPrice, formatPercent, formatNumber } from '@/hooks/useCrypto';
import { Skeleton } from '@/components/ui/skeleton';
import PriceChart from './PriceChart';
import CryptoStats from './CryptoStats';
import { ArrowLeft, Star, Share2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface CryptoDetailViewProps {
  coinId: string;
}

export default function CryptoDetailView({ coinId }: CryptoDetailViewProps) {
  const { data: crypto, isLoading, error } = useCryptocurrency(coinId);
  const [_, setLocation] = useLocation();

  if (error) {
    return (
      <div className="p-8 text-center">
        <p className="text-red-500">Error loading cryptocurrency data. Please try again later.</p>
        <Button onClick={() => setLocation('/')} className="mt-4">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Cryptocurrencies
        </Button>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-6">
        <Button
          variant="ghost"
          size="sm"
          className="mb-4 text-primary"
          onClick={() => setLocation('/')}
        >
          <ArrowLeft className="mr-1 h-4 w-4" />
          Back to Cryptocurrencies
        </Button>
        
        <div className="flex flex-col md:flex-row md:items-center">
          {isLoading ? (
            <>
              <div className="flex items-center">
                <Skeleton className="h-10 w-10 rounded-full" />
                <Skeleton className="h-8 w-48 ml-3" />
                <Skeleton className="h-6 w-16 ml-3" />
              </div>
              <div className="mt-4 md:mt-0 md:ml-auto">
                <Skeleton className="h-8 w-32" />
              </div>
            </>
          ) : (
            <>
              <div className="flex items-center">
                <img className="h-10 w-10 rounded-full" src={crypto?.image} alt={crypto?.name} />
                <h1 className="ml-3 text-2xl font-bold">{crypto?.name} ({crypto?.symbol})</h1>
                <span className="ml-3 px-2 py-1 bg-neutral-100 dark:bg-neutral-700 text-neutral-600 dark:text-neutral-300 text-xs rounded-md">
                  Rank #{crypto?.marketCapRank || 'N/A'}
                </span>
              </div>
              <div className="mt-4 md:mt-0 md:ml-auto flex space-x-2">
                <Button variant="outline" size="sm">
                  <Star className="mr-1 h-4 w-4" />
                  Watchlist
                </Button>
                <Button variant="outline" size="sm">
                  <Share2 className="mr-1 h-4 w-4" />
                  Share
                </Button>
              </div>
            </>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div className="bg-white dark:bg-neutral-800 rounded-lg shadow p-6 mb-6">
            {isLoading ? (
              <>
                <div className="flex flex-col md:flex-row md:items-end justify-between mb-6">
                  <div>
                    <Skeleton className="h-10 w-40" />
                    <Skeleton className="h-5 w-24 mt-1" />
                  </div>
                  <div className="mt-4 md:mt-0">
                    <Skeleton className="h-8 w-64" />
                  </div>
                </div>
                <Skeleton className="h-64 w-full" />
              </>
            ) : (
              <>
                <div className="flex flex-col md:flex-row md:items-end justify-between mb-6">
                  <div>
                    <div className="flex items-baseline">
                      <span className="text-3xl font-bold">{formatPrice(crypto?.currentPrice)}</span>
                      <span className={`ml-2 text-lg ${
                        crypto?.priceChangePercentage24h && crypto.priceChangePercentage24h >= 0 
                          ? 'text-green-500' 
                          : 'text-red-500'
                      }`}>
                        {formatPercent(crypto?.priceChangePercentage24h)}
                      </span>
                    </div>
                    <p className="text-neutral-500 dark:text-neutral-400 text-sm mt-1">
                      {/* This would typically come from an API that provides conversion rates */}
                      0.99431 ETH
                    </p>
                  </div>
                  <div className="mt-4 md:mt-0">
                    <div className="flex space-x-2 text-sm">
                      <Button variant="outline" size="sm">24h</Button>
                      <Button size="sm">7d</Button>
                      <Button variant="outline" size="sm">30d</Button>
                      <Button variant="outline" size="sm">90d</Button>
                      <Button variant="outline" size="sm">1y</Button>
                      <Button variant="outline" size="sm">All</Button>
                    </div>
                  </div>
                </div>
                <PriceChart coinId={crypto?.coinId || ''} />
              </>
            )}
          </div>

          <div className="bg-white dark:bg-neutral-800 rounded-lg shadow p-6 mb-6">
            <h2 className="text-xl font-bold mb-4">Market Stats</h2>
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[...Array(9)].map((_, index) => (
                  <div key={index}>
                    <Skeleton className="h-4 w-32 mb-2" />
                    <Skeleton className="h-6 w-24" />
                    <Skeleton className="h-4 w-16 mt-1" />
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <p className="text-sm text-neutral-500 dark:text-neutral-400">Market Cap</p>
                  <p className="font-medium">{formatPrice(crypto?.marketCap)}</p>
                  <p className={`text-xs ${
                    crypto?.marketCapChangePercentage24h && crypto.marketCapChangePercentage24h >= 0 
                      ? 'text-green-500' 
                      : 'text-red-500'
                  }`}>
                    {formatPercent(crypto?.marketCapChangePercentage24h)}{' '}
                    <span className="text-neutral-500 dark:text-neutral-400">(24h)</span>
                  </p>
                </div>
                <div>
                  <p className="text-sm text-neutral-500 dark:text-neutral-400">Fully Diluted Market Cap</p>
                  <p className="font-medium">
                    {crypto?.maxSupply && crypto.currentPrice
                      ? formatPrice(crypto.maxSupply * crypto.currentPrice)
                      : 'N/A'
                    }
                  </p>
                </div>
                <div>
                  <p className="text-sm text-neutral-500 dark:text-neutral-400">Volume / Market Cap</p>
                  <p className="font-medium">
                    {crypto?.marketCap && crypto.totalVolume && crypto.marketCap > 0
                      ? (crypto.totalVolume / crypto.marketCap).toFixed(5)
                      : 'N/A'
                    }
                  </p>
                </div>
                <div>
                  <p className="text-sm text-neutral-500 dark:text-neutral-400">24h Trading Volume</p>
                  <p className="font-medium">{formatPrice(crypto?.totalVolume)}</p>
                  {/* Volume change is not provided by our API directly */}
                  <p className="text-xs text-neutral-400">—</p>
                </div>
                <div>
                  <p className="text-sm text-neutral-500 dark:text-neutral-400">Circulating Supply</p>
                  <p className="font-medium">
                    {formatNumber(crypto?.circulatingSupply)} {crypto?.symbol}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-neutral-500 dark:text-neutral-400">Max Supply</p>
                  <p className="font-medium">
                    {crypto?.maxSupply ? `${formatNumber(crypto.maxSupply)} ${crypto.symbol}` : '∞'}
                  </p>
                </div>
              </div>
            )}
          </div>

          <div className="bg-white dark:bg-neutral-800 rounded-lg shadow p-6">
            <h2 className="text-xl font-bold mb-4">About {crypto?.name || 'Cryptocurrency'}</h2>
            {isLoading ? (
              <div className="space-y-4">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-3/4" />
              </div>
            ) : (
              <div className="text-sm text-neutral-700 dark:text-neutral-300 space-y-4">
                {crypto?.name === 'Bitcoin' ? (
                  <>
                    <p>Bitcoin (BTC) is a decentralized cryptocurrency originally described in a 2008 whitepaper by a person, or group of people, using the alias Satoshi Nakamoto. It was launched soon after, in January 2009.</p>
                    <p>Bitcoin is a peer-to-peer online currency, meaning that all transactions happen directly between equal, independent network participants, without the need for any intermediary to permit or facilitate them. Bitcoin was created, according to Nakamoto's own words, to allow "online payments to be sent directly from one party to another without going through a financial institution."</p>
                    <p>Some concepts for a similar type of a decentralized electronic currency precede BTC, but Bitcoin holds the distinction of being the first-ever cryptocurrency to come into actual use.</p>
                  </>
                ) : (
                  <p>Information about {crypto?.name} is not available at this time.</p>
                )}
              </div>
            )}
          </div>
        </div>

        <div>
          <CryptoStats crypto={crypto} isLoading={isLoading} />
        </div>
      </div>
    </div>
  );
}
