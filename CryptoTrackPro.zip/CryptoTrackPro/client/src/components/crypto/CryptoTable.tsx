import { useState } from 'react';
import { Link } from 'wouter';
import { useCryptocurrencies, formatPrice, formatPercent, formatNumber } from '@/hooks/useCrypto';
import { Skeleton } from '@/components/ui/skeleton';
import CryptoPagination from './CryptoPagination';
import { ArrowDownUp, ArrowDown, ArrowUp } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type SortOrder = 'asc' | 'desc';
type SortField = 'marketCapRank' | 'name' | 'price' | 'marketCap' | 'change24h';

export default function CryptoTable() {
  const [page, setPage] = useState(1);
  const [limit] = useState(10); // Default to 10 items per page
  const [currency, setCurrency] = useState('usd');
  const [sortField, setSortField] = useState<SortField>('marketCapRank');
  const [sortOrder, setSortOrder] = useState<SortOrder>('asc');
  
  const { data, isLoading, error } = useCryptocurrencies(page, limit, currency, sortField, sortOrder);

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };
  
  const getSortIcon = (field: SortField) => {
    if (sortField !== field) return <ArrowDownUp className="h-4 w-4 inline ml-1" />;
    return sortOrder === 'asc' ? <ArrowUp className="h-4 w-4 inline ml-1" /> : <ArrowDown className="h-4 w-4 inline ml-1" />;
  };

  if (error) {
    return (
      <div className="p-8 text-center">
        <p className="text-red-500">Error loading cryptocurrency data. Please try again later.</p>
      </div>
    );
  }

  return (
    <div>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <h1 className="text-2xl font-bold mb-2 md:mb-0">Today's Cryptocurrency Prices</h1>
        <div className="flex space-x-2">
          <Select
            value={currency}
            onValueChange={(value) => setCurrency(value)}
          >
            <SelectTrigger className="w-[120px]">
              <SelectValue placeholder="Currency" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="usd">USD</SelectItem>
              <SelectItem value="eur">EUR</SelectItem>
              <SelectItem value="gbp">GBP</SelectItem>
              <SelectItem value="jpy">JPY</SelectItem>
            </SelectContent>
          </Select>
          
          <Select
            value={`${sortField}-${sortOrder}`}
            onValueChange={(value) => {
              const [field, order] = value.split('-') as [SortField, SortOrder];
              setSortField(field);
              setSortOrder(order);
            }}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="marketCapRank-asc">Rank: Low to High</SelectItem>
              <SelectItem value="marketCapRank-desc">Rank: High to Low</SelectItem>
              <SelectItem value="name-asc">Name: A to Z</SelectItem>
              <SelectItem value="name-desc">Name: Z to A</SelectItem>
              <SelectItem value="price-asc">Price: Low to High</SelectItem>
              <SelectItem value="price-desc">Price: High to Low</SelectItem>
              <SelectItem value="marketCap-desc">Market Cap: High to Low</SelectItem>
              <SelectItem value="marketCap-asc">Market Cap: Low to High</SelectItem>
              <SelectItem value="change24h-desc">Change 24h: High to Low</SelectItem>
              <SelectItem value="change24h-asc">Change 24h: Low to High</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="overflow-x-auto bg-white dark:bg-neutral-800 rounded-lg shadow">
        <table className="min-w-full divide-y divide-neutral-200 dark:divide-neutral-700">
          <thead className="bg-neutral-100 dark:bg-neutral-700">
            <tr>
              <th 
                scope="col" 
                className="px-4 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider w-8 cursor-pointer"
                onClick={() => toggleSort('marketCapRank')}
              >
                # {getSortIcon('marketCapRank')}
              </th>
              <th 
                scope="col" 
                className="px-4 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider cursor-pointer"
                onClick={() => toggleSort('name')}
              >
                Name {getSortIcon('name')}
              </th>
              <th 
                scope="col" 
                className="px-4 py-3 text-right text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider cursor-pointer"
                onClick={() => toggleSort('price')}
              >
                Price {getSortIcon('price')}
              </th>
              <th 
                scope="col" 
                className="px-4 py-3 text-right text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider cursor-pointer"
                onClick={() => toggleSort('change24h')}
              >
                24h % {getSortIcon('change24h')}
              </th>
              <th 
                scope="col" 
                className="px-4 py-3 text-right text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider"
              >
                7d %
              </th>
              <th 
                scope="col" 
                className="px-4 py-3 text-right text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider cursor-pointer"
                onClick={() => toggleSort('marketCap')}
              >
                Market Cap {getSortIcon('marketCap')}
              </th>
              <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Volume(24h)</th>
              <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Circulating Supply</th>
              <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Last 7 Days</th>
            </tr>
          </thead>
          <tbody className="bg-white dark:bg-neutral-800 divide-y divide-neutral-200 dark:divide-neutral-700">
            {isLoading ? (
              Array(limit).fill(0).map((_, index) => (
                <tr key={index}>
                  <td className="px-4 py-4 whitespace-nowrap"><Skeleton className="h-5 w-5" /></td>
                  <td className="px-4 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <Skeleton className="h-6 w-6 rounded-full" />
                      <div className="ml-3">
                        <Skeleton className="h-5 w-24" />
                        <Skeleton className="h-4 w-12 mt-1" />
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-right"><Skeleton className="h-5 w-20 ml-auto" /></td>
                  <td className="px-4 py-4 whitespace-nowrap text-right"><Skeleton className="h-5 w-16 ml-auto" /></td>
                  <td className="px-4 py-4 whitespace-nowrap text-right"><Skeleton className="h-5 w-16 ml-auto" /></td>
                  <td className="px-4 py-4 whitespace-nowrap text-right"><Skeleton className="h-5 w-24 ml-auto" /></td>
                  <td className="px-4 py-4 whitespace-nowrap text-right"><Skeleton className="h-5 w-24 ml-auto" /></td>
                  <td className="px-4 py-4 whitespace-nowrap text-right"><Skeleton className="h-5 w-28 ml-auto" /></td>
                  <td className="px-4 py-4 whitespace-nowrap text-right"><Skeleton className="h-10 w-20 ml-auto" /></td>
                </tr>
              ))
            ) : (
              data?.data.map((crypto) => (
                <tr key={crypto.id} className="hover:bg-neutral-50 dark:hover:bg-neutral-700 cursor-pointer">
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-neutral-500 dark:text-neutral-400">
                    {crypto.marketCapRank || 'N/A'}
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap">
                    <Link href={`/crypto/${crypto.coinId}`}>
                      <div className="flex items-center">
                        <img className="h-6 w-6 rounded-full" src={crypto.image} alt={crypto.name} />
                        <div className="ml-3">
                          <div className="text-sm font-medium">{crypto.name}</div>
                          <div className="text-xs text-neutral-500 dark:text-neutral-400">{crypto.symbol}</div>
                        </div>
                      </div>
                    </Link>
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-right font-medium">
                    {formatPrice(crypto.currentPrice)}
                  </td>
                  <td className={`px-4 py-4 whitespace-nowrap text-sm text-right ${
                    crypto.priceChangePercentage24h && crypto.priceChangePercentage24h >= 0 
                      ? 'text-green-500' 
                      : 'text-red-500'
                  }`}>
                    {formatPercent(crypto.priceChangePercentage24h)}
                  </td>
                  <td className={`px-4 py-4 whitespace-nowrap text-sm text-right ${
                    crypto.priceChangePercentage7d && crypto.priceChangePercentage7d >= 0 
                      ? 'text-green-500' 
                      : 'text-red-500'
                  }`}>
                    {formatPercent(crypto.priceChangePercentage7d)}
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-right">
                    {formatPrice(crypto.marketCap)}
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-right">
                    {formatPrice(crypto.totalVolume)}
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-right">
                    <div>{formatNumber(crypto.circulatingSupply)} {crypto.symbol}</div>
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-right text-sm">
                    <svg className="h-10 w-20 ml-auto" viewBox="0 0 100 30" preserveAspectRatio="none">
                      <path 
                        d="M0 15 L10 13 L20 17 L30 9 L40 12 L50 10 L60 15 L70 7 L80 14 L90 10 L100 15" 
                        fill="none" 
                        stroke={crypto.priceChangePercentage7d && crypto.priceChangePercentage7d >= 0 ? "#16C784" : "#EA3943"} 
                        strokeWidth="2" 
                      />
                    </svg>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
        
        {!isLoading && data && (
          <CryptoPagination
            currentPage={page}
            totalPages={data.pagination.totalPages}
            onPageChange={setPage}
            totalItems={data.pagination.total}
            itemsPerPage={limit}
          />
        )}
      </div>
    </div>
  );
}
