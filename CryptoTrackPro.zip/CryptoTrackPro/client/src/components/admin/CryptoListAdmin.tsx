import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Cryptocurrency } from '@shared/schema';
import { formatPrice, formatNumber } from '@/hooks/useCrypto';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import CryptoForm from './CryptoForm';
import CryptoPagination from '../crypto/CryptoPagination';
import { Skeleton } from '@/components/ui/skeleton';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Edit, Trash2, Search } from 'lucide-react';

export default function CryptoListAdmin() {
  const [page, setPage] = useState(1);
  const [limit] = useState(10);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('marketCap');
  const { toast } = useToast();

  // Fetch all cryptocurrencies for admin
  const { data, isLoading, error } = useQuery<Cryptocurrency[]>({
    queryKey: ['/api/admin/cryptocurrencies'],
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/admin/cryptocurrencies/${id}`);
    },
    onSuccess: () => {
      toast({
        title: 'Success',
        description: 'Cryptocurrency has been deleted.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/cryptocurrencies'] });
      queryClient.invalidateQueries({ queryKey: ['/api/cryptocurrencies'] });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: 'Failed to delete cryptocurrency.',
        variant: 'destructive',
      });
      console.error('Delete error:', error);
    },
  });

  // Filter and sort data
  const filteredData = data
    ? data.filter(crypto => 
        crypto.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        crypto.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
        crypto.coinId.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  // Sort data
  const sortedData = [...filteredData].sort((a, b) => {
    if (sortBy === 'name') {
      return a.name.localeCompare(b.name);
    } else if (sortBy === 'price') {
      return (b.currentPrice || 0) - (a.currentPrice || 0);
    } else if (sortBy === 'rank') {
      return (a.marketCapRank || 9999) - (b.marketCapRank || 9999);
    } else if (sortBy === 'added') {
      return b.id - a.id; // Most recently added first
    } else {
      // Default sort by marketCap
      return (b.marketCap || 0) - (a.marketCap || 0);
    }
  });

  // Paginate data
  const paginatedData = sortedData.slice((page - 1) * limit, page * limit);
  const totalPages = Math.ceil(sortedData.length / limit);

  if (error) {
    return (
      <div className="p-8 text-center">
        <p className="text-red-500">Error loading cryptocurrency data. Please try again later.</p>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-neutral-800 rounded-lg shadow p-6 mb-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Manage Cryptocurrency Listings</h2>
        <CryptoForm buttonLabel="Add New Cryptocurrency" />
      </div>

      <div className="mb-4 flex justify-between items-center">
        <div className="relative">
          <Input
            type="text"
            placeholder="Search cryptocurrencies..."
            className="pl-10 pr-4 py-2 w-64"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <div className="absolute left-3 top-2.5 text-neutral-400">
            <Search className="h-4 w-4" />
          </div>
        </div>
        <div className="flex space-x-2">
          <Select
            value={sortBy}
            onValueChange={setSortBy}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="marketCap">Sort by: Market Cap</SelectItem>
              <SelectItem value="name">Sort by: Name</SelectItem>
              <SelectItem value="price">Sort by: Price</SelectItem>
              <SelectItem value="rank">Sort by: Rank</SelectItem>
              <SelectItem value="added">Sort by: Recently Added</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-neutral-200 dark:divide-neutral-700">
          <thead className="bg-neutral-100 dark:bg-neutral-700">
            <tr>
              <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">#</th>
              <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Name</th>
              <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Price</th>
              <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Status</th>
              <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Last Updated</th>
              <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white dark:bg-neutral-800 divide-y divide-neutral-200 dark:divide-neutral-700">
            {isLoading ? (
              Array(limit).fill(0).map((_, index) => (
                <tr key={index}>
                  <td className="px-4 py-4 whitespace-nowrap"><Skeleton className="h-5 w-5" /></td>
                  <td className="px-4 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <Skeleton className="h-6 w-6 rounded-full" />
                      <div className="ml-3">
                        <Skeleton className="h-5 w-24" />
                        <Skeleton className="h-4 w-12 mt-1" />
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-right"><Skeleton className="h-5 w-20 ml-auto" /></td>
                  <td className="px-4 py-4 whitespace-nowrap text-right"><Skeleton className="h-5 w-16 ml-auto" /></td>
                  <td className="px-4 py-4 whitespace-nowrap text-right"><Skeleton className="h-5 w-24 ml-auto" /></td>
                  <td className="px-4 py-4 whitespace-nowrap text-right"><Skeleton className="h-5 w-20 ml-auto" /></td>
                </tr>
              ))
            ) : (
              paginatedData.map((crypto) => (
                <tr key={crypto.id}>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-neutral-500 dark:text-neutral-400">
                    {crypto.marketCapRank || 'N/A'}
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <img className="h-6 w-6 rounded-full" src={crypto.image} alt={crypto.name} />
                      <div className="ml-3">
                        <div className="text-sm font-medium">{crypto.name}</div>
                        <div className="text-xs text-neutral-500 dark:text-neutral-400">{crypto.symbol}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm text-right font-medium">
                    {formatPrice(crypto.currentPrice)}
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-right">
                    <span className={`px-2 py-1 ${
                      crypto.isActive
                        ? 'bg-green-100 text-green-500 dark:bg-green-900 dark:text-green-300'
                        : 'bg-neutral-100 text-neutral-500 dark:bg-neutral-700 dark:text-neutral-300'
                    } text-xs rounded-full`}>
                      {crypto.isActive ? 'Active' : 'Paused'}
                    </span>
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-right text-sm text-neutral-500 dark:text-neutral-400">
                    {crypto.lastUpdated 
                      ? new Date(crypto.lastUpdated).toLocaleString()
                      : 'N/A'}
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-right text-sm">
                    <div className="flex justify-end space-x-2">
                      <CryptoForm
                        crypto={crypto}
                        buttonLabel=""
                        buttonVariant="ghost"
                      >
                        <Edit className="h-4 w-4 text-neutral-500 hover:text-primary" />
                      </CryptoForm>

                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <Trash2 className="h-4 w-4 text-neutral-500 hover:text-red-500" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                            <AlertDialogDescription>
                              This will delete {crypto.name} ({crypto.symbol}) from the system.
                              This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction 
                              onClick={() => deleteMutation.mutate(crypto.id)}
                              className="bg-red-500 hover:bg-red-600"
                            >
                              {deleteMutation.isPending ? 'Deleting...' : 'Delete'}
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
        
        {!isLoading && (
          <CryptoPagination
            currentPage={page}
            totalPages={totalPages}
            onPageChange={setPage}
            totalItems={filteredData.length}
            itemsPerPage={limit}
          />
        )}
      </div>
    </div>
  );
}
