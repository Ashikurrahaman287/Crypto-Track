import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { insertCryptoSchema, Cryptocurrency } from '@shared/schema';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Loader2 } from 'lucide-react';

interface CryptoFormProps {
  crypto?: Cryptocurrency;
  onSuccess?: () => void;
  buttonLabel?: string;
  buttonVariant?: 'default' | 'outline' | 'destructive' | 'secondary' | 'ghost' | 'link';
}

// Extend the insert schema with some additional validation
const formSchema = insertCryptoSchema.extend({
  name: z.string().min(1, 'Name is required'),
  symbol: z.string().min(1, 'Symbol is required').max(10, 'Symbol too long').toUpperCase(),
  coinId: z.string().min(1, 'Coin ID is required'),
  image: z.string().url('Must be a valid URL'),
  currentPrice: z.coerce.number().optional(),
  marketCap: z.coerce.number().optional(),
  totalVolume: z.coerce.number().optional(),
  circulatingSupply: z.coerce.number().optional(),
  totalSupply: z.coerce.number().optional(),
  maxSupply: z.coerce.number().optional(),
});

export default function CryptoForm({ crypto, onSuccess, buttonLabel = 'Add Cryptocurrency', buttonVariant = 'default' }: CryptoFormProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: crypto || {
      name: '',
      symbol: '',
      coinId: '',
      image: '',
      currentPrice: 0,
      marketCap: 0,
      totalVolume: 0,
      circulatingSupply: 0,
      totalSupply: 0,
      maxSupply: 0,
      isActive: true,
    },
  });

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    setIsSubmitting(true);
    try {
      if (crypto) {
        // Update existing crypto
        await apiRequest('PUT', `/api/admin/cryptocurrencies/${crypto.id}`, values);
        toast({
          title: 'Success',
          description: `${values.name} has been updated.`,
        });
      } else {
        // Create new crypto
        await apiRequest('POST', '/api/admin/cryptocurrencies', values);
        toast({
          title: 'Success',
          description: `${values.name} has been added.`,
        });
      }
      
      // Invalidate queries to refetch data
      queryClient.invalidateQueries({ queryKey: ['/api/admin/cryptocurrencies'] });
      queryClient.invalidateQueries({ queryKey: ['/api/cryptocurrencies'] });
      
      // Close modal and reset form
      setIsOpen(false);
      form.reset();
      
      if (onSuccess) {
        onSuccess();
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: `Failed to ${crypto ? 'update' : 'add'} cryptocurrency.`,
        variant: 'destructive',
      });
      console.error('Form submission error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant={buttonVariant}>{buttonLabel}</Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>
            {crypto ? `Edit ${crypto.name}` : 'Add New Cryptocurrency'}
          </DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 py-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Bitcoin" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="symbol"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Symbol</FormLabel>
                    <FormControl>
                      <Input placeholder="BTC" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="coinId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Coin ID</FormLabel>
                    <FormControl>
                      <Input placeholder="bitcoin" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="image"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Image URL</FormLabel>
                    <FormControl>
                      <Input placeholder="https://example.com/image.png" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="currentPrice"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Current Price (USD)</FormLabel>
                    <FormControl>
                      <Input type="number" step="any" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="marketCap"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Market Cap (USD)</FormLabel>
                    <FormControl>
                      <Input type="number" step="any" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="circulatingSupply"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Circulating Supply</FormLabel>
                    <FormControl>
                      <Input type="number" step="any" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="maxSupply"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Max Supply</FormLabel>
                    <FormControl>
                      <Input type="number" step="any" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="isActive"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                  <div className="space-y-0.5">
                    <FormLabel className="text-base">Active Status</FormLabel>
                    <div className="text-sm text-neutral-500 dark:text-neutral-400">
                      Determine if this cryptocurrency should be visible to users
                    </div>
                  </div>
                  <FormControl>
                    <Switch
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                </FormItem>
              )}
            />
            
            <div className="flex justify-end space-x-2">
              <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {crypto ? 'Update' : 'Add'} Cryptocurrency
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
