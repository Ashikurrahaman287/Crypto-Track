import { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useGlobalStats, formatNumber, formatPrice } from '@/hooks/useCrypto';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import CryptoListAdmin from '@/components/admin/CryptoListAdmin';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  List,
  BarChart,
  Settings,
  Shield,
  LogOut,
} from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

export default function AdminPage() {
  const { user, logoutMutation } = useAuth();
  const [activeView, setActiveView] = useState('listings');
  const { data: stats, isLoading: statsLoading } = useGlobalStats();

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">Admin Panel</h1>
          <div className="flex items-center space-x-2">
            <span className="text-sm text-neutral-500 dark:text-neutral-400 mr-2">
              Logged in as {user?.username}
            </span>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleLogout}
              disabled={logoutMutation.isPending}
            >
              {logoutMutation.isPending ? 'Logging out...' : 'Logout'}
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-1 space-y-4">
            <div className="bg-white dark:bg-neutral-800 rounded-lg shadow p-4">
              <h2 className="text-lg font-medium mb-3">Dashboard</h2>
              <nav className="space-y-1">
                <Button
                  variant={activeView === 'listings' ? 'default' : 'ghost'}
                  className="w-full justify-start"
                  onClick={() => setActiveView('listings')}
                >
                  <List className="mr-2 h-5 w-5" />
                  <span>Manage Listings</span>
                </Button>
                <Button
                  variant={activeView === 'analytics' ? 'default' : 'ghost'}
                  className="w-full justify-start"
                  onClick={() => setActiveView('analytics')}
                >
                  <BarChart className="mr-2 h-5 w-5" />
                  <span>Analytics</span>
                </Button>
                <Button
                  variant={activeView === 'settings' ? 'default' : 'ghost'}
                  className="w-full justify-start"
                  onClick={() => setActiveView('settings')}
                >
                  <Settings className="mr-2 h-5 w-5" />
                  <span>Settings</span>
                </Button>
                <Button
                  variant={activeView === 'apikeys' ? 'default' : 'ghost'}
                  className="w-full justify-start"
                  onClick={() => setActiveView('apikeys')}
                >
                  <Shield className="mr-2 h-5 w-5" />
                  <span>API Keys</span>
                </Button>
              </nav>
            </div>

            <div className="bg-white dark:bg-neutral-800 rounded-lg shadow p-4">
              <h2 className="text-lg font-medium mb-3">System Status</h2>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm">API Connection</span>
                  <span className="px-2 py-1 bg-green-100 text-green-600 dark:bg-green-900 dark:text-green-300 text-xs rounded-full">
                    Online
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Database</span>
                  <span className="px-2 py-1 bg-green-100 text-green-600 dark:bg-green-900 dark:text-green-300 text-xs rounded-full">
                    Online
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Last Update</span>
                  <span className="text-sm">
                    {new Date().toLocaleTimeString()}
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-3">
            {/* Market Overview Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-neutral-500 dark:text-neutral-400">
                    Total Cryptocurrencies
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {statsLoading ? (
                    <Skeleton className="h-9 w-16" />
                  ) : (
                    <p className="text-2xl font-bold">{formatNumber(stats?.totalCryptocurrencies)}</p>
                  )}
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-neutral-500 dark:text-neutral-400">
                    Total Exchanges
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {statsLoading ? (
                    <Skeleton className="h-9 w-16" />
                  ) : (
                    <p className="text-2xl font-bold">{formatNumber(stats?.totalExchanges)}</p>
                  )}
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-neutral-500 dark:text-neutral-400">
                    Total Market Cap
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {statsLoading ? (
                    <Skeleton className="h-9 w-24" />
                  ) : (
                    <p className="text-2xl font-bold">{formatPrice(stats?.totalMarketCap)}</p>
                  )}
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-neutral-500 dark:text-neutral-400">
                    24h Volume
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {statsLoading ? (
                    <Skeleton className="h-9 w-24" />
                  ) : (
                    <p className="text-2xl font-bold">{formatPrice(stats?.totalVolume)}</p>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Views */}
            {activeView === 'listings' && <CryptoListAdmin />}
            
            {activeView === 'analytics' && (
              <Card>
                <CardHeader>
                  <CardTitle>Analytics</CardTitle>
                  <CardDescription>
                    View market trends and cryptocurrency performance metrics.
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex justify-center items-center h-64">
                  <p className="text-neutral-500 dark:text-neutral-400">
                    Analytics dashboard coming soon.
                  </p>
                </CardContent>
              </Card>
            )}
            
            {activeView === 'settings' && (
              <Card>
                <CardHeader>
                  <CardTitle>Settings</CardTitle>
                  <CardDescription>
                    Configure admin dashboard preferences and system settings.
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex justify-center items-center h-64">
                  <p className="text-neutral-500 dark:text-neutral-400">
                    Settings dashboard coming soon.
                  </p>
                </CardContent>
              </Card>
            )}
            
            {activeView === 'apikeys' && (
              <Card>
                <CardHeader>
                  <CardTitle>API Keys</CardTitle>
                  <CardDescription>
                    Manage API keys and integration settings.
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex justify-center items-center h-64">
                  <p className="text-neutral-500 dark:text-neutral-400">
                    API key management coming soon.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
