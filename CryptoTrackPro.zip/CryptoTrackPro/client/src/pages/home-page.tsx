import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import MarketOverview from '@/components/layout/MarketOverview';
import CryptoTable from '@/components/crypto/CryptoTable';

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <MarketOverview />
      <main className="flex-grow container mx-auto px-4 py-6">
        <CryptoTable />
      </main>
      <Footer />
    </div>
  );
}
