import { useParams } from 'wouter';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import MarketOverview from '@/components/layout/MarketOverview';
import CryptoDetailView from '@/components/crypto/CryptoDetailView';

export default function CryptoDetailPage() {
  const { coinId } = useParams();
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <MarketOverview />
      <main className="flex-grow container mx-auto px-4 py-6">
        <CryptoDetailView coinId={coinId || ''} />
      </main>
      <Footer />
    </div>
  );
}
