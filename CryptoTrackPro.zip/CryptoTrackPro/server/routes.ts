import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import axios from "axios";
import { insertCryptoSchema } from "@shared/schema";
import { promisify } from "util";
import { randomBytes, scrypt } from "crypto";

// CoinGecko API endpoints
const COINGECKO_API_BASE = "https://api.coingecko.com/api/v3";
const FETCH_INTERVAL = 5 * 60 * 1000; // 5 minutes

// Add authentication middleware for admin routes
const isAuthenticated = (req: Request, res: Response, next: Function) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes (/api/login, /api/register, /api/logout, /api/user)
  setupAuth(app);

  // Fetch crypto data from CoinGecko
  const fetchCryptoData = async () => {
    try {
      const response = await axios.get(
        `${COINGECKO_API_BASE}/coins/markets`,
        {
          params: {
            vs_currency: "usd",
            order: "market_cap_desc",
            per_page: 100,
            page: 1,
            sparkline: false,
            price_change_percentage: "7d",
          },
        }
      );

      // Map CoinGecko response to our schema
      const cryptos = response.data.map((coin: any) => ({
        coinId: coin.id,
        name: coin.name,
        symbol: coin.symbol.toUpperCase(),
        image: coin.image,
        currentPrice: coin.current_price,
        marketCap: coin.market_cap,
        marketCapRank: coin.market_cap_rank,
        totalVolume: coin.total_volume,
        high24h: coin.high_24h,
        low24h: coin.low_24h,
        priceChange24h: coin.price_change_24h,
        priceChangePercentage24h: coin.price_change_percentage_24h,
        marketCapChange24h: coin.market_cap_change_24h,
        marketCapChangePercentage24h: coin.market_cap_change_percentage_24h,
        circulatingSupply: coin.circulating_supply,
        totalSupply: coin.total_supply,
        maxSupply: coin.max_supply,
        ath: coin.ath,
        athChangePercentage: coin.ath_change_percentage,
        athDate: coin.ath_date,
        atl: coin.atl,
        atlChangePercentage: coin.atl_change_percentage,
        atlDate: coin.atl_date,
        lastUpdated: coin.last_updated,
        priceChangePercentage7d: coin.price_change_percentage_7d_in_currency,
        isActive: true,
      }));

      // Update crypto data in storage
      for (const crypto of cryptos) {
        const exists = await storage.getCryptocurrencyByCoinId(crypto.coinId);
        if (exists) {
          await storage.updateCryptocurrency(exists.id, crypto);
        } else {
          await storage.createCryptocurrency(crypto);
        }
      }

      console.log(`Updated ${cryptos.length} cryptocurrencies from CoinGecko`);
    } catch (error) {
      console.error("Error fetching cryptocurrency data:", error);
    }
  };

  // Initial fetch
  await fetchCryptoData();

  // Schedule regular updates
  setInterval(fetchCryptoData, FETCH_INTERVAL);

  // Public API routes
  app.get("/api/cryptocurrencies", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 100;
      const page = parseInt(req.query.page as string) || 1;
      const currency = (req.query.currency as string) || "usd";
      const orderBy = (req.query.orderBy as string) || "marketCapRank";
      const order = (req.query.order as string) || "asc";

      let cryptos = await storage.getAllCryptocurrencies();

      // Filter active cryptocurrencies
      cryptos = cryptos.filter(crypto => crypto.isActive);

      // Sorting logic
      if (orderBy === "name") {
        cryptos.sort((a, b) => {
          return order === "asc"
            ? a.name.localeCompare(b.name)
            : b.name.localeCompare(a.name);
        });
      } else if (orderBy === "price") {
        cryptos.sort((a, b) => {
          const aPrice = a.currentPrice || 0;
          const bPrice = b.currentPrice || 0;
          return order === "asc" ? aPrice - bPrice : bPrice - aPrice;
        });
      } else if (orderBy === "marketCap") {
        cryptos.sort((a, b) => {
          const aMarketCap = a.marketCap || 0;
          const bMarketCap = b.marketCap || 0;
          return order === "asc" ? aMarketCap - bMarketCap : bMarketCap - aMarketCap;
        });
      } else if (orderBy === "change24h") {
        cryptos.sort((a, b) => {
          const aChange = a.priceChangePercentage24h || 0;
          const bChange = b.priceChangePercentage24h || 0;
          return order === "asc" ? aChange - bChange : bChange - aChange;
        });
      } else {
        // Default sort by marketCapRank
        cryptos.sort((a, b) => {
          const aRank = a.marketCapRank || 999999;
          const bRank = b.marketCapRank || 999999;
          return order === "asc" ? aRank - bRank : bRank - aRank;
        });
      }

      // Pagination
      const startIndex = (page - 1) * limit;
      const endIndex = page * limit;
      const paginatedCryptos = cryptos.slice(startIndex, endIndex);
      
      // Calculate total pages
      const totalPages = Math.ceil(cryptos.length / limit);

      res.json({
        data: paginatedCryptos,
        pagination: {
          total: cryptos.length,
          page,
          limit,
          totalPages
        }
      });
    } catch (error) {
      console.error("Error fetching cryptocurrencies:", error);
      res.status(500).json({ message: "Failed to fetch cryptocurrency data" });
    }
  });

  app.get("/api/cryptocurrencies/:id", async (req, res) => {
    try {
      // Support both numeric IDs and coin IDs (strings)
      let crypto;
      if (!isNaN(parseInt(req.params.id))) {
        crypto = await storage.getCryptocurrencyById(parseInt(req.params.id));
      } else {
        crypto = await storage.getCryptocurrencyByCoinId(req.params.id);
      }

      if (!crypto) {
        return res.status(404).json({ message: "Cryptocurrency not found" });
      }

      res.json(crypto);
    } catch (error) {
      console.error("Error fetching cryptocurrency:", error);
      res.status(500).json({ message: "Failed to fetch cryptocurrency data" });
    }
  });

  app.get("/api/stats/global", async (req, res) => {
    try {
      const response = await axios.get(`${COINGECKO_API_BASE}/global`);
      const { data } = response;

      res.json({
        totalCryptocurrencies: data.data.active_cryptocurrencies,
        totalExchanges: data.data.markets,
        totalMarketCap: data.data.total_market_cap.usd,
        totalVolume: data.data.total_volume.usd,
        marketCapPercentage: data.data.market_cap_percentage,
        marketCapChangePercentage24h: data.data.market_cap_change_percentage_24h_usd
      });
    } catch (error) {
      console.error("Error fetching global stats:", error);
      res.status(500).json({ message: "Failed to fetch global stats" });
    }
  });

  // Admin API routes (protected)
  app.get("/api/admin/cryptocurrencies", isAuthenticated, async (req, res) => {
    try {
      const cryptos = await storage.getAllCryptocurrencies();
      res.json(cryptos);
    } catch (error) {
      console.error("Error fetching all cryptocurrencies:", error);
      res.status(500).json({ message: "Failed to fetch cryptocurrency data" });
    }
  });

  app.post("/api/admin/cryptocurrencies", isAuthenticated, async (req, res) => {
    try {
      const validationResult = insertCryptoSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ message: "Invalid crypto data", errors: validationResult.error.errors });
      }

      const exists = await storage.getCryptocurrencyByCoinId(req.body.coinId);
      if (exists) {
        return res.status(400).json({ message: "Cryptocurrency with this ID already exists" });
      }

      const crypto = await storage.createCryptocurrency(req.body);
      res.status(201).json(crypto);
    } catch (error) {
      console.error("Error creating cryptocurrency:", error);
      res.status(500).json({ message: "Failed to create cryptocurrency" });
    }
  });

  app.put("/api/admin/cryptocurrencies/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const exists = await storage.getCryptocurrencyById(id);
      if (!exists) {
        return res.status(404).json({ message: "Cryptocurrency not found" });
      }

      const crypto = await storage.updateCryptocurrency(id, req.body);
      res.json(crypto);
    } catch (error) {
      console.error("Error updating cryptocurrency:", error);
      res.status(500).json({ message: "Failed to update cryptocurrency" });
    }
  });

  app.delete("/api/admin/cryptocurrencies/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const exists = await storage.getCryptocurrencyById(id);
      if (!exists) {
        return res.status(404).json({ message: "Cryptocurrency not found" });
      }

      await storage.deleteCryptocurrency(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting cryptocurrency:", error);
      res.status(500).json({ message: "Failed to delete cryptocurrency" });
    }
  });

  // Create a sample admin user if none exists
  const createSampleAdmin = async () => {
    try {
      const existingAdmin = await storage.getUserByUsername("admin");
      if (!existingAdmin) {
        const scryptAsync = promisify(scrypt);
        const salt = randomBytes(16).toString("hex");
        const buf = (await scryptAsync("admin123", salt, 64)) as Buffer;
        const hashedPassword = `${buf.toString("hex")}.${salt}`;
        
        await storage.createUser({
          username: "admin",
          password: hashedPassword
        });
        console.log("Created sample admin user (username: admin, password: admin123)");
      }
    } catch (error) {
      console.error("Error creating sample admin user:", error);
    }
  };

  // Create sample admin on startup
  await createSampleAdmin();

  const httpServer = createServer(app);

  return httpServer;
}
