import { users, type User, type InsertUser, cryptocurrencies, type Cryptocurrency, type InsertCrypto } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import { db } from "./db";
import { eq, sql } from "drizzle-orm";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const MemoryStore = createMemoryStore(session);
const PostgresSessionStore = connectPg(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Crypto methods
  getAllCryptocurrencies(): Promise<Cryptocurrency[]>;
  getCryptocurrencyById(id: number): Promise<Cryptocurrency | undefined>;
  getCryptocurrencyBySymbol(symbol: string): Promise<Cryptocurrency | undefined>;
  getCryptocurrencyByCoinId(coinId: string): Promise<Cryptocurrency | undefined>;
  createCryptocurrency(crypto: InsertCrypto): Promise<Cryptocurrency>;
  updateCryptocurrency(id: number, crypto: Partial<InsertCrypto>): Promise<Cryptocurrency | undefined>;
  deleteCryptocurrency(id: number): Promise<boolean>;
  updateCryptocurrencyPrices(cryptos: Partial<InsertCrypto>[]): Promise<void>;
  sessionStore: session.SessionStore;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.SessionStore;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  async getAllCryptocurrencies(): Promise<Cryptocurrency[]> {
    return await db.select().from(cryptocurrencies);
  }

  async getCryptocurrencyById(id: number): Promise<Cryptocurrency | undefined> {
    const result = await db.select().from(cryptocurrencies).where(eq(cryptocurrencies.id, id));
    return result[0];
  }

  async getCryptocurrencyBySymbol(symbol: string): Promise<Cryptocurrency | undefined> {
    const result = await db.select().from(cryptocurrencies).where(eq(cryptocurrencies.symbol, symbol));
    return result[0];
  }

  async getCryptocurrencyByCoinId(coinId: string): Promise<Cryptocurrency | undefined> {
    const result = await db.select().from(cryptocurrencies).where(eq(cryptocurrencies.coinId, coinId));
    return result[0];
  }

  async createCryptocurrency(crypto: InsertCrypto): Promise<Cryptocurrency> {
    const result = await db.insert(cryptocurrencies).values(crypto).returning();
    return result[0];
  }

  async updateCryptocurrency(id: number, crypto: Partial<InsertCrypto>): Promise<Cryptocurrency | undefined> {
    const result = await db
      .update(cryptocurrencies)
      .set(crypto)
      .where(eq(cryptocurrencies.id, id))
      .returning();
    return result[0];
  }

  async deleteCryptocurrency(id: number): Promise<boolean> {
    const result = await db
      .delete(cryptocurrencies)
      .where(eq(cryptocurrencies.id, id))
      .returning();
    return result.length > 0;
  }

  async updateCryptocurrencyPrices(cryptos: Partial<InsertCrypto>[]): Promise<void> {
    for (const crypto of cryptos) {
      if (!crypto.coinId) continue;
      
      const existingCrypto = await this.getCryptocurrencyByCoinId(crypto.coinId);
      if (existingCrypto) {
        await this.updateCryptocurrency(existingCrypto.id, crypto);
      } else {
        // Create a new cryptocurrency if it doesn't exist
        if (crypto.name && crypto.symbol && crypto.image) {
          await this.createCryptocurrency(crypto as InsertCrypto);
        }
      }
    }
  }
}

// Replace MemStorage with DatabaseStorage
export const storage = new DatabaseStorage();
