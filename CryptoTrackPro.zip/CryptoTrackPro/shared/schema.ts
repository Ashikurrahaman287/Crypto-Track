import { pgTable, text, serial, integer, boolean, timestamp, real, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const cryptocurrencies = pgTable("cryptocurrencies", {
  id: serial("id").primaryKey(),
  coinId: text("coin_id").notNull().unique(), // CoinGecko ID
  name: text("name").notNull(),
  symbol: text("symbol").notNull(),
  image: text("image").notNull(),
  currentPrice: real("current_price"),
  marketCap: real("market_cap"),
  marketCapRank: integer("market_cap_rank"),
  totalVolume: real("total_volume"),
  high24h: real("high_24h"),
  low24h: real("low_24h"),
  priceChange24h: real("price_change_24h"),
  priceChangePercentage24h: real("price_change_percentage_24h"),
  marketCapChange24h: real("market_cap_change_24h"),
  marketCapChangePercentage24h: real("market_cap_change_percentage_24h"),
  circulatingSupply: real("circulating_supply"),
  totalSupply: real("total_supply"),
  maxSupply: real("max_supply"),
  ath: real("ath"),
  athChangePercentage: real("ath_change_percentage"),
  athDate: varchar("ath_date", { length: 30 }),
  atl: real("atl"),
  atlChangePercentage: real("atl_change_percentage"),
  atlDate: varchar("atl_date", { length: 30 }),
  lastUpdated: varchar("last_updated", { length: 30 }),
  priceChangePercentage7d: real("price_change_percentage_7d"),
  isActive: boolean("is_active").default(true),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertCryptoSchema = createInsertSchema(cryptocurrencies).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertCrypto = z.infer<typeof insertCryptoSchema>;
export type Cryptocurrency = typeof cryptocurrencies.$inferSelect;
